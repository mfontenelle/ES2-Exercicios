package ex04;

public interface ReceitaFederal {
    public boolean isCPFBloqueado(String cpf);
}
